import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-validate-otp',
  templateUrl: './validate-otp.page.html',
  styleUrls: ['./validate-otp.page.scss'],
})
export class ValidateOtpPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
