import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-send-mail',
  templateUrl: './customer-send-mail.page.html',
  styleUrls: ['./customer-send-mail.page.scss'],
})
export class CustomerSendMailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
