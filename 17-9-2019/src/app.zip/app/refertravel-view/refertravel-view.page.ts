import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-refertravel-view',
  templateUrl: './refertravel-view.page.html',
  styleUrls: ['./refertravel-view.page.scss'],
})
export class RefertravelViewPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
