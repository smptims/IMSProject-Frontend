import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicecenter-send-mail',
  templateUrl: './servicecenter-send-mail.page.html',
  styleUrls: ['./servicecenter-send-mail.page.scss'],
})
export class ServicecenterSendMailPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
