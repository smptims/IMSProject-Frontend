import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicecenter-send-sms',
  templateUrl: './servicecenter-send-sms.page.html',
  styleUrls: ['./servicecenter-send-sms.page.scss'],
})
export class ServicecenterSendSmsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
