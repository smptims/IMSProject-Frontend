import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicecenter-notifications',
  templateUrl: './servicecenter-notifications.page.html',
  styleUrls: ['./servicecenter-notifications.page.scss'],
})
export class ServicecenterNotificationsPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
